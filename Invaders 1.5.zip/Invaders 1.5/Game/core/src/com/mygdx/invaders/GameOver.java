package com.mygdx.invaders;
    
import java.io.*;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.ScreenUtils;

public class GameOver implements Screen{

    private int width = 350;
    private int height = 100;
    private Invaders game;
    private int button_width = 100;
    private int button_height = 100;
    private BackGround bg;
    private int score;
    private String record;
    private Texture GameOver;   
    private BitmapFont score_font;
    private Texture exit_overing;
    private Texture exit;
    private Texture retry_overing;
    private Texture retry;


    public GameOver(Invaders game, int score){
        this.game = game;
        this.score = score;
        bg = new BackGround();
        exit = new Texture("GameOver/Close_BTN.png");
        exit_overing = new Texture("GameOver/Close_BTN_active.png");
        retry = new Texture("GameOver/Replay_BTN.png");
        retry_overing = new Texture("GameOver/Replay_BTN_active.png");
        GameOver = new Texture("GameOver/Lost.png");
        score_font = new BitmapFont(Gdx.files.internal("GUI/score_font _active.fnt"));
        try {
            updateRecord();
        } catch (IOException ioe){
            ioe.printStackTrace();
        }
    }

    public void updateRecord() throws IOException{
            BufferedReader br = new BufferedReader(new FileReader("core\\src\\com\\mygdx\\invaders\\Record.txt"));
            record = br.readLine();
            br.close();
            if (score > Integer.parseInt(record)) {
                BufferedWriter bw = new BufferedWriter(new FileWriter("core\\src\\com\\mygdx\\invaders\\Record.txt"));
                bw.write(""+score);
                record = ""+score;
                bw.flush();
                bw.close();
            }
            
    }

    @Override
    public void show() {
        
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0,0);
        game.batch.begin();
        bg.drawBGM(game.batch);
        game.batch.draw(GameOver, (Gdx.graphics.getWidth()/2)-(width/2), Gdx.graphics.getHeight()/2, width, height);
        GlyphLayout score_layout = new GlyphLayout(score_font, "Score: \n" + score, Color.WHITE, 0, Align.left, false);
        GlyphLayout record_layout = new GlyphLayout(score_font, "Record: \n" + record, Color.WHITE, 0, Align.left, false);
        score_font.draw(game.batch, score_layout, 200, 200);
        score_font.draw(game.batch, record_layout, 200, 100) ;

        if (Gdx.input.getX() > 525 && Gdx.input.getX() < Gdx.graphics.getWidth() && (500 - Gdx.input.getY()) > 150 && (500 - Gdx.input.getY()) < 225) {
            game.batch.draw(retry_overing, 525, 125, button_width, button_height);
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Difficulty(game));
            }
        } else {
            game.batch.draw(retry, 525, 125, button_width, button_height);
        }

        if (Gdx.input.getX() > 525 && Gdx.input.getX() < Gdx.graphics.getWidth() && (500 - Gdx.input.getY()) > 0 && (500 - Gdx.input.getY()) < 100) {
            game.batch.draw(exit_overing, 525, 0, button_width, button_height);
            if (Gdx.input.isTouched()) {
                Gdx.app.exit();
            }
        } else {
            game.batch.draw(exit, 525, 0, button_width, button_height);
        }

        game.batch.end();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {
 
    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {
    
    }

    @Override
    public void dispose() {
  
    }
    
}
