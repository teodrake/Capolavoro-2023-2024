package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.ScreenUtils;

public class Menu implements Screen{

    private int button_width = 125;
    private int button_height = 125;
    private BackGround bg;
    private Invaders game;
    private Texture play_overing;
    private Texture play;
    private Texture exit_overing;
    private Texture exit;
    private Texture tutorial_overing;
    private Texture tutorial;
    private Texture title;
    

    public Menu(Invaders game){
        this.game = game;
        bg = new BackGround();
        title = new Texture("Menu/Title.png");
        play_overing = new Texture("Menu/Play_BTN_active.png");
        exit_overing = new Texture("Menu/Close_BTN_active.png");
        tutorial_overing = new Texture("Menu/Info_BTN_active.png");
        play = new Texture("Menu/Play_BTN.png");
        exit = new Texture("Menu/Close_BTN.png");
        tutorial = new Texture("Menu/Info_BTN.png");
    }

    @Override
    public void show() {
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0,0);
        game.batch.begin();
        bg.drawBGM(game.batch);
        game.batch.draw(title, 75, 250, button_width*4, button_height);
        if (Gdx.input.getX() > 75 && Gdx.input.getX() < 200 && (500 - Gdx.input.getY()) > 0 && (500 - Gdx.input.getY()) < 125) {
            game.batch.draw(tutorial_overing, 75, 0, button_width, button_height);
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Tutorial(game));
            }
        } else {
            game.batch.draw(tutorial, 75, 0, button_width, button_height);
        }

        if (Gdx.input.getX() > 265 && Gdx.input.getX() < 390 && (500 - Gdx.input.getY()) > 0 && (500 - Gdx.input.getY()) < 125) {
            game.batch.draw(play_overing, 265, 0, button_width, button_height);
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Difficulty(game));
            }
        } else {
            game.batch.draw(play, 265, 0, button_width, button_height);
        }

        if (Gdx.input.getX() > 450 && Gdx.input.getX() < 575 && (500 - Gdx.input.getY()) > 0 && (500 - Gdx.input.getY()) < 125) {
            game.batch.draw(exit_overing, 450, 0, button_width, button_height);
            if (Gdx.input.isTouched()) {
                Gdx.app.exit();
            }
        } else {
            game.batch.draw(exit, 450, 0, button_width, button_height);
        }
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
    }
    
}
