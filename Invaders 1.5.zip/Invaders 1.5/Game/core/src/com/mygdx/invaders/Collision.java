package com.mygdx.invaders;

public class Collision {
    private float x;
    private float y;
    private int width;
    private int height;

    public Collision(float x, float y, int width, int height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void move(float x, float y){
        this.x = x;
        this.y = y;
    }

    public boolean collided(Collision reaction){
        if (x < reaction.x + reaction.width && y < reaction.y + reaction.height && x + width > reaction.x && y+height > reaction.y) {
            return true;
        } else {
            return false;
        }
    }
}
