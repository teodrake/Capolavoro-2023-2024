package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.utils.ScreenUtils;

public class Difficulty implements Screen{

    private Invaders game;
    private BackGround bg = new BackGround();
    private BitmapFont difficulty_font_active = new BitmapFont(Gdx.files.internal("GUI/score_font _active.fnt"));
    private BitmapFont difficulty_font = new BitmapFont(Gdx.files.internal("GUI/score_font.fnt"));
    private GlyphLayout[] difficulties_layouts = {new GlyphLayout(difficulty_font, "Easy"), new GlyphLayout(difficulty_font, "Medium"), new GlyphLayout(difficulty_font, "Hard")};
    private Texture exit_overing = new Texture("Menu/Close_BTN_active.png");
    private Texture exit = new Texture("Menu/Close_BTN.png");
    private Texture window = new Texture("Controls/Window.png");

    public Difficulty(Invaders game){
        this.game = game;
    }

    @Override
    public void show() {
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0,0);
        game.batch.begin();
        bg.drawBGM(game.batch);
        game.batch.draw(window, 50, 25, 550, 425);
        if (Gdx.input.getX() > 200 && Gdx.input.getX() < 350 && (500 - Gdx.input.getY()) > 335 && (500 - Gdx.input.getY()) < 370) {
            difficulty_font_active.draw(game.batch, difficulties_layouts[0], 200, 350);
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new GameScreen(game, 1));
            }
        } else {
            difficulty_font.draw(game.batch, difficulties_layouts[0], 200, 350);
        }
        if (Gdx.input.getX() > 200 && Gdx.input.getX() < 395 && (500 - Gdx.input.getY()) > 235 && (500 - Gdx.input.getY()) < 270) {
            difficulty_font_active.draw(game.batch, difficulties_layouts[1], 200, 250); 
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new GameScreen(game, 2));
            }   
        } else {
            difficulty_font.draw(game.batch, difficulties_layouts[1], 200, 250);
        }
        if (Gdx.input.getX() > 200 && Gdx.input.getX() < 325 && (500 - Gdx.input.getY()) > 135 && (500 - Gdx.input.getY()) < 170) {
            difficulty_font_active.draw(game.batch, difficulties_layouts[2], 200, 150);  
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new GameScreen(game, 3));
            }  
        } else {
            difficulty_font.draw(game.batch, difficulties_layouts[2], 200, 150);
        }
        if (Gdx.input.getX() > 540 && Gdx.input.getX() < 570 && (500 - Gdx.input.getY()) > 425 && (500 - Gdx.input.getY()) < 460) {
            game.batch.draw(exit_overing, 540, 410, 30, 30);
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Menu(game));
            }
        } else {
            game.batch.draw(exit, 540, 410, 30, 30);
        }
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
    }
    
}
