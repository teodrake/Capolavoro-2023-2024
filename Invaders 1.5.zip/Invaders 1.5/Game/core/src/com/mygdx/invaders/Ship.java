package com.mygdx.invaders;

import com.badlogic.gdx.graphics.Texture;

public class Ship {
    private Texture ship;
    private Collision col;

    public Ship(){
        this.ship = new Texture("Ships/Ship6.png");
        col = new Collision(300, 25, 50, 95);
    }

    public Texture getShip(){
        return ship;
    }

    public Collision getCollision(){
        return col;
    }
}
