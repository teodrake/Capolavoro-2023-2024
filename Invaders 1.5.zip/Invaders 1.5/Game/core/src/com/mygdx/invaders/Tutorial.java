package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.utils.ScreenUtils;

public class Tutorial implements Screen{

    private Invaders game;
    private BitmapFont controls_font = new BitmapFont(Gdx.files.internal("GUI/score_font.fnt"));
    private GlyphLayout[] controls_layouts = {new GlyphLayout(controls_font, "Dx"), new GlyphLayout(controls_font, "Sx"), new GlyphLayout(controls_font, "Super"), new GlyphLayout(controls_font, "Shoot!")};
    private BackGround bg = new BackGround();
    private Texture window = new Texture("Controls/Window.png");
    private Texture under_key = new Texture("Controls/Bonus_BTN_01.png");
    private Texture Left_Arrow = new Texture("Controls/arrow_left.png");
    private Texture Right_Arrow = new Texture("Controls/arrow_right.png");
    private Texture F = new Texture("Controls/F.png");
    private Texture Q = new Texture("Controls/Q.png");
    private Texture E = new Texture("Controls/E.png");
    private Texture R = new Texture("Controls/R.png");
    private Texture T = new Texture("Controls/T.png");
    private Texture[] bonuses = {new Texture("Bonus/HP_Icon.png"), new Texture("Bonus/Armor_Icon.png"), new Texture("Bonus/Charger_icon.png"), new Texture("Bonus/Speed_Icon.png")};
    private Texture Space = new Texture("Controls/Space.png");
    private Texture Space_Word = new Texture("Controls/Space_word.png");
    private Texture exit_overing = new Texture("Menu/Close_BTN_active.png");
    private Texture exit = new Texture("Menu/Close_BTN.png");
    

    public Tutorial(Invaders game){
        this.game = game;
    }

    @Override
    public void show() {
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0,0,0,0);
        game.batch.begin();
        bg.drawBGM(game.batch);
        game.batch.draw(window, 50, 25, 550, 425);
        game.batch.draw(under_key, 100, 75, 75,75);
        game.batch.draw(under_key, 267, 75, 75,75);
        game.batch.draw(under_key, 435, 75, 75,75);
        game.batch.draw(under_key, 100, 190, 75,75);
        game.batch.draw(under_key, 267, 190, 75,75);
        game.batch.draw(under_key, 435, 190, 75,75);
        game.batch.draw(under_key, 335, 300, 75,75);
        game.batch.draw(Left_Arrow, 88, 70, 90,90);
        game.batch.draw(Right_Arrow, 95, 177, 90,90);
        game.batch.draw(F, 350, 310, 45,45);
        game.batch.draw(Q, 278, 86, 45,45);
        game.batch.draw(E, 284, 202, 40,40);
        game.batch.draw(R, 449, 88, 45,45);
        game.batch.draw(T, 450, 200, 45,45);
        game.batch.draw(bonuses[0], 350, 80, 55, 50);
        game.batch.draw(bonuses[1], 350, 200, 55, 50);
        game.batch.draw(bonuses[2], 515, 80, 55, 50);
        game.batch.draw(bonuses[3], 515, 200, 55, 50);
        game.batch.draw(Space, 75, 325, 250, 50);
        game.batch.draw(Space_Word, 88, 338, 220, 30);
        controls_font.draw(game.batch, controls_layouts[0], 190, 235);
        controls_font.draw(game.batch, controls_layouts[1], 190, 120);
        controls_font.draw(game.batch, controls_layouts[2], 420, 345);
        controls_font.draw(game.batch, controls_layouts[3], 105, 325);
        if (Gdx.input.getX() > 540 && Gdx.input.getX() < 570 && (500 - Gdx.input.getY()) > 425 && (500 - Gdx.input.getY()) < 460) {
            game.batch.draw(exit_overing, 540, 410, 30, 30);
            if (Gdx.input.isTouched()) {
                this.dispose();
                game.setScreen(new Menu(game));
            }
        } else {
            game.batch.draw(exit, 540, 410, 30, 30);
        }
        
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
    }
    
}
