package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Bonus {
    private GameScreen gs;
    private GUI gui;
    private Texture[] bonuses = {new Texture("Bonus/HP_Icon.png"), new Texture("Bonus/Armor_Icon.png"), new Texture("Bonus/Charger_icon.png"), new Texture("Bonus/Speed_Icon.png")};
    private Texture[] bonuses_empty = {new Texture("Bonus/HP_empty_Icon.png"), new Texture("Bonus/Armor_empty_Icon.png"), new Texture("Bonus/Charger_empty_icon.png"), new Texture("Bonus/Speed_empty_Icon.png")};
    private Texture bonus_head = new Texture("Bonus/Header.png");
    private boolean[] gotBonus = {false, false, false, false};

    public Bonus(GUI gui, GameScreen gs){
        this.gui = gui;
        this.gs = gs;
    }

    public void update(){
        if (Gdx.input.isKeyJustPressed(Keys.Q) && gotBonus[0] == true) {
            gotBonus[0] = false;
            gui.setHPWidth(200);
            gs.hp = 10;
            gs.score += 20;
        }
        if (Gdx.input.isKeyJustPressed(Keys.E) && gotBonus[1] == true) {
            gotBonus[1] = false;
                gui.invincible();
                gs.score += 20;
        }
        if (Gdx.input.isKeyJustPressed(Keys.R) && gotBonus[2] == true) {
            gotBonus[2] = false;
            for (int i=0; i<2; i++){
                gui.updateSuper();
            }
            gs.score += 20;
        }
        if (Gdx.input.isKeyJustPressed(Keys.T) && gotBonus[3] == true) {
            gotBonus[3] = false;
                gs.SPEED = 300;
                gs.score += 20;
        }
    }

    public void render(SpriteBatch batch, int num){
        batch.draw(bonus_head, 15, 140, 100, 40);
        if (num < gotBonus.length) {
            gotBonus[num] = true;
        }

        if (gotBonus[0] == true) {
            batch.draw(bonuses[0], 10, 30, 45, 40);
        } else if (gotBonus[0] == false){
            batch.draw(bonuses_empty[0], 10, 30, 45, 40);
        }

        if (gotBonus[1] == true) {
            batch.draw(bonuses[1], 70, 30, 45, 40);
        } else if (gotBonus[1] == false) {
            batch.draw(bonuses_empty[1], 70, 30, 45, 40);
        }
        
        if (gotBonus[2] == true) {
            batch.draw(bonuses[2], 10, 80, 45, 40);
        } else if (gotBonus[2] == false){
            batch.draw(bonuses_empty[2], 10, 80, 45, 40);
        }

        if (gotBonus[3] == true) {
            batch.draw(bonuses[3], 70, 80, 45, 40);
        } else if (gotBonus[3] == false){
            batch.draw(bonuses_empty[3], 70, 80, 45, 40);
        }
    }


}
