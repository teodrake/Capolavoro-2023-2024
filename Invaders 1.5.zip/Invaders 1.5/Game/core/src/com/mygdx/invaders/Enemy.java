package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Enemy {
    private int SPEED;
    private Texture frame;
    private float x;
    private float y;
    private Collision col;
    private boolean remove = false;

    public Enemy(float x, int SPEED){
        this.x = x;
        this.y = Gdx.graphics.getHeight();
        this.col = new Collision(x, y, 20, 40);
        this.SPEED = SPEED;
        if (frame == null){
            frame = new Texture("Enemy/Ship3.png");
        }
    }

    public void update(float deltaTime){
        y -= SPEED * deltaTime;
        if (y < 0) {
            remove = true;
        }
        col.move(x, y);
    }

    public void render(SpriteBatch batch){
        batch.draw(frame, x, y, 20, 40);
    }

    public boolean getRemove(){
        return remove;
    }

    public Collision getCollision(){
        return col;
    }

    public float getX(){
        return this.x;
    }

    public float getY(){
        return this.y;
    }
}
