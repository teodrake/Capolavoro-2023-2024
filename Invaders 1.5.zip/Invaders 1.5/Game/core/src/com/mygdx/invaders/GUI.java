package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GUI {
    private Texture hp = new Texture("GUI/HP_Bar.png");
    private Texture hp_container = new Texture("GUI/Health_Bar_Table.png");
    private Texture super_container = new Texture("GUI/Super_Bar_Table.png");
    private Texture super_bar = new Texture("GUI/Super_Bar.png");
    private Texture score = new Texture("GUI/Score.png");
    private Texture record = new Texture("GUI/Record.png");
    private Texture wawe = new Texture("GUI/Wawe_counter.png");
    private int hp_width = 165;
    private int super_width = 0;
    
    public void drawGUI(SpriteBatch batch){
        batch.draw(hp_container, 126, 0, 200, 30);
        batch.draw(hp, 129, 3, hp_width, 24);
        batch.draw(super_container, 326, 0, 200, 30);
        batch.draw(super_bar, 358, 3, super_width, 24);
        batch.draw(score, 530, 350, 100, 40);
        batch.draw(record, 530, 175, 100, 40);
        batch.draw(wawe, 15, 380, 100, 40);
    }

    public void updateHP(){
        if (hp_width > 0) {
            hp_width -= 15;
        }
    }

    public void updateSuper(){
        if (super_width<165 && !Gdx.input.isKeyPressed(Keys.F)) {
            super_width += 33;
        }else if (Gdx.input.isKeyPressed(Keys.F) && super_width == 165){
            super_width = 0;
        }
    }

    public int getSuperWidth(){
        return this.super_width;
    }

    public void setHPWidth(int hp_width){
        this.hp_width = hp_width;
    }

    public void invincible(){
        hp = new Texture("GUI/HP_Bar_Invincible.png");
    }

    public String getHPTexture(){
        return hp.toString();
    }

    public void setHPTexture(String path){
        this.hp = new Texture(path);
    }
}
