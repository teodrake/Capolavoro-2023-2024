package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Projectile {
    private int SPEED = 500;
    private Texture frame;
    private Collision col;
    private float x;
    private float y;
    private int damage;
    private boolean remove = false;

    public Projectile(int damage, float x, float y, Texture frame){
        this.x = x;
        this.y = y;
        this.col = new Collision(x, y, 3, 12);
        if (this.frame == null){
            this.frame = frame;
        }
    }

    public void update(float deltaTime){
        y += SPEED * deltaTime;
        if (y > Gdx.graphics.getHeight()) {
            remove = true;
        }
        col.move(x, y);
    }

    public void updateEnemy(float deltaTime){
        y -= SPEED * deltaTime;
        if (y < 0) {
            remove = true;
        }
        col.move(x, y);
    }

    public void render(SpriteBatch batch){
        batch.draw(frame, x, y);
    }

    public int getDamage(){
        return damage;
    }

    public boolean getRemove(){
        return remove;
    }

    public Collision getCollision(){
        return col;
    }
}
