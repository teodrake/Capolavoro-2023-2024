package com.mygdx.invaders;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.utils.ScreenUtils;

public class GameScreen implements Screen{
    
    float SPEED = 200;  //Velocità di movimento della navicella
    float x;    //Posizione della navicella sull'asse X
    float y;    //Posizione della navicella sull'asse Y
    Invaders game;
    BackGround bg; 
    Ship player;
    int hp;
    GUI gui;
    int max_enemy;
    int score;
    BufferedReader br;
    int killed_enemies;
    String record;
    BitmapFont score_font;
    ArrayList<Projectile> bullets;
    ArrayList<Enemy> enemies;
    ArrayList<Projectile> enemy_bullets;
    Bonus bonus;
    float Shot_To_Shot_Timer = 0.3f;    //Intervallo di tempo minimo tra un proiettile e l'altro, è necessario per impedire al giocatore di sparare in continuazione
    float shot_Timer;   //Timer necessario a cronometrare il tempo passato dall'ultimo sparo di un proiettile
    float double_SPEED_timer;
    float double_SPEED_duration = 5f;
    float invincibility_duration = 5f;
    float invincibility_timer;
    float enemy_Shot_To_Shot_Timer = 1.3f;
    float enemy_shot_Timer;
    float min_enemy_spawn_time = 1.3f;  //Tempo minimo tra la comparsa di un nemico e un'altro
    float max_enemy_spawn_time = 1.6f;  //Tempo massimo tra la comparsa di un nemico e un'altro
    float EnemySpawnTimer;  //Timer necessario a cronometrare il tempo passato dall'ultima comparsa di un nemico
    int enemies_num;    //Variabile necessaria per tenere conto del numero di nemici comparsi durante la partita, il numero massimo cambierà in base alla difficoltà
    Random random;
    int random_bonus_number; //Numero per estrarre un bonus casuale
    int bonus_chance; //Probabilità di ottenere un bonus ad ogni kill
    boolean invincible = false;
    int wawes;
    int wawes_numeber;
    int difficulty;


    //Costruttore dello schermo di gioco dove inizializzo le variabili
    public GameScreen(Invaders game, int difficulty){
        this.game = game;
        this.difficulty = difficulty;
        killed_enemies = 0;
        double_SPEED_timer = 0;
        invincibility_timer = 0;
        shot_Timer = 0;
        bullets = new ArrayList<Projectile>();
        enemies  = new ArrayList<Enemy>();
        enemy_bullets = new ArrayList<Projectile>();
        player = new Ship();
        bg = new BackGround();
        x = 300;
        y = 32;
        wawes = 1;
        random_bonus_number = 10;
        bonus_chance = 10;
        max_enemy = 5*difficulty;
        score_font = new BitmapFont(Gdx.files.internal("GUI/score_font.fnt"));
        gui = new GUI();
        bonus = new Bonus(gui, this);
        score = 0;
        hp = 11;
        wawes_numeber = 5*difficulty;
        random = new Random();
        EnemySpawnTimer = random.nextFloat() * (max_enemy_spawn_time - min_enemy_spawn_time) + min_enemy_spawn_time;
        try{
            br = new BufferedReader(new FileReader("core\\src\\com\\mygdx\\invaders\\Record.txt"));
            record = br.readLine();
            br.close();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
        enemies_num = 0;
    }

    @Override
    public void show() {
        
    }

    @Override
    public void render(float delta) {

        //Codice per far finire il bonus di velocità quando necessario
        if (SPEED == 300) {
            double_SPEED_timer += delta;
        }
        if (double_SPEED_timer > double_SPEED_duration) {
            SPEED = 150;
            double_SPEED_timer = 0;
        }

        //Codice per far finire il bonus di invincibilità quando necessario
        if (gui.getHPTexture().equals("GUI/HP_Bar_Invincible.png")) {
            invincibility_timer += delta;
            invincible = true;
        }
        if (invincibility_timer > invincibility_duration) {
            gui.setHPTexture("GUI/HP_Bar.png");
            invincible = false;
            invincibility_timer = 0;
        }

        //Codice per far partire il proiettile
        shot_Timer += delta;
        if (Gdx.input.isKeyPressed(Keys.SPACE) && shot_Timer >= Shot_To_Shot_Timer){
            shot_Timer = 0;
            bullets.add(new Projectile(1, x+25, 40, new Texture("Bullets/Bullet6.png")));
        }

        //Codice per far partire il proiettile nemico
        enemy_shot_Timer += delta;
        if (enemy_shot_Timer >= enemy_Shot_To_Shot_Timer && !enemies.isEmpty()){
            enemy_shot_Timer = 0;
            int rand_enemy = random.nextInt(enemies.size());
            enemy_bullets.add(new Projectile(1, enemies.get(rand_enemy).getX()+7, enemies.get(rand_enemy).getY()-40, new Texture("Bullets/EnemyBullet.png")));
        }

        //Codice per aggiornare lo stato del proiettile
        ArrayList<Projectile> bullets_remove = new ArrayList<Projectile>();
        for (Projectile bullet : bullets){
            bullet.update(delta);
            if (bullet.getRemove()){
                bullets_remove.add(bullet);
            }
        }
        bullets.removeAll(bullets_remove);

        //Codice per aggiornare lo stato del proiettile della nave nemica
        ArrayList<Projectile> enemy_bullets_remove = new ArrayList<Projectile>();
        for (Projectile bullet : enemy_bullets){
            bullet.updateEnemy(delta);
            if (bullet.getRemove()){
                enemy_bullets_remove.add(bullet);
            }
        }
        enemy_bullets.removeAll(enemy_bullets_remove);

        //Codice per far comparire i nemici
        EnemySpawnTimer -= delta;
        if (EnemySpawnTimer <= 0 && enemies_num<max_enemy) {
            EnemySpawnTimer = random.nextFloat() * (max_enemy_spawn_time - min_enemy_spawn_time) + min_enemy_spawn_time;
            int enemy_x = random.nextInt(Gdx.graphics.getWidth()-150);
            if (enemy_x < 150){
                enemy_x += 150;
            }
            enemies.add(new Enemy(enemy_x, 50*difficulty));
            enemies_num++;
        }

        //Codice per aggiornare lo stato dei nemici
        ArrayList<Enemy> enemies_remove = new ArrayList<Enemy>();
        for (Enemy enemy : enemies){
            enemy.update(delta);
            if (enemy.getRemove()) {
                enemies_remove.add(enemy);
                hp--;
                gui.updateHP();
                killed_enemies++;
            }
        }
        enemies.removeAll(enemies_remove);

        //Codice per muovere la navicella
        if (Gdx.input.isKeyPressed(Keys.LEFT)) {
            x -= SPEED * Gdx.graphics.getDeltaTime();
            if (x - 125 < 0) {
                x = 125;
            }
        }
        if (Gdx.input.isKeyPressed(Keys.RIGHT)) {
            x += SPEED * Gdx.graphics.getDeltaTime();
            if (x + 166 > Gdx.graphics.getWidth()){
                x = Gdx.graphics.getWidth() - 166;
            }
        }
        if (Gdx.input.isKeyPressed(Keys.F)) {
            if (gui.getSuperWidth() == 165) {
                gui.updateSuper();
                if (enemies_num-killed_enemies > 0) {
                    for (int i=0; i<enemies_num-killed_enemies; i++){
                    enemies.remove(0);
                    score += 30;
                    }
                }
            }
        }
        
        player.getCollision().move(x, 0);

        //Codice per controllare le collisioni tra proiettile nemico e nave del giocatore
        for (Projectile bullet : enemy_bullets){
            if (bullet.getCollision().collided(player.getCollision())) {
                bullets_remove.add(bullet);
                if (!invincible) {
                    hp--;
                    gui.updateHP();   
                }
            }
        }
        enemy_bullets.removeAll(bullets_remove);

        //Codice per controllare le collisioni tra proiettile sparato dal player e nave nemica
        for (Projectile bullet : bullets){
            for (Enemy enemy : enemies){
                if (bullet.getCollision().collided(enemy.getCollision())){
                    bullets_remove.add(bullet);
                    enemies_remove.add(enemy);
                    if (random.nextInt(15)+1  > bonus_chance) {
                        random_bonus_number = random.nextInt(4);
                    }
                    killed_enemies++;
                    score += 10;
                    gui.updateSuper();
                }
            }
        }
        bullets.removeAll(bullets_remove);
        enemies.removeAll(enemies_remove);

        //Codice per controllare le collisioni tra nave nemica e player
        for(Enemy enemy :  enemies){
            if (enemy.getCollision().collided(player.getCollision())) {
                enemies_remove.add(enemy);
                killed_enemies++;
                hp--;
                gui.updateHP();
            }
        }
        enemies.removeAll(enemies_remove);

        //Codice per aggiornare i bonus
        bonus.update();

        

        //Codice di disegno
        ScreenUtils.clear(0,0,0,0);
        game.batch.begin();
        bg.drawBG(game.batch);
        GlyphLayout score_layout = new GlyphLayout(score_font, "" + score);
        score_font.draw(game.batch, score_layout, 530, 300);
        GlyphLayout record_layout = new GlyphLayout(score_font, record);
        score_font.draw(game.batch, record_layout, 530, 125);
        GlyphLayout wawe_layout = new GlyphLayout(score_font, ""+ wawes);
        score_font.draw(game.batch, wawe_layout, 55, 350);
        gui.drawGUI(game.batch);
        bg.update(delta);
        for (Projectile bullet : bullets){
            bullet.render(game.batch);
        }
        for (Enemy enemy : enemies){
            enemy.render(game.batch);
        }
        for (Projectile bullet : enemy_bullets){
            bullet.render(game.batch);
        }
        bonus.render(game.batch, random_bonus_number);
        game.batch.draw(player.getShip(), x, y, 50, 75);
        if (hp > 0 && enemies_num == max_enemy && enemies.isEmpty() && wawes < wawes_numeber) {
            wawes++;
            enemies_num = 0;
            killed_enemies = 0;
        }else if (hp == 0){
            bullets.clear();
            enemies.clear();
            enemies_num = max_enemy;
            game.setScreen(new GameOver(game, score));
        }else if (enemies_num == max_enemy && enemies.isEmpty()) {
            bullets.clear();
            game.setScreen(new Winner(game, score));
        }
        random_bonus_number = 10;
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {}
}
