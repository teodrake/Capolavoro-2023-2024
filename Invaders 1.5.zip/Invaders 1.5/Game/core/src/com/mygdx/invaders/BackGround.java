package com.mygdx.invaders;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class BackGround {
private Texture BackGround1 = new Texture("Background/BG.png");
private Texture BackGround2 = new Texture("Background/BG.png");
private Texture BlackBars = new Texture("BackGround/BlackBars.png");
private int SPEED = 50;
private float y1 = 1;
private float y2 = Gdx.graphics.getHeight();

public BackGround(){}

public void drawBG(SpriteBatch batch){
    batch.draw(BackGround1, 126, y1, 526, Gdx.graphics.getHeight()+2);
    batch.draw(BackGround2, 126, y2, 526, Gdx.graphics.getHeight()+2);
    batch.draw(BlackBars, 0, 0, 650, 500);
}

public void drawBGM(SpriteBatch batch){
    batch.draw(BackGround1, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
}

public void update(float deltaTime){
    y1 -= SPEED * deltaTime;
    y2 -= SPEED * deltaTime;
    if (y1<0-Gdx.graphics.getHeight()) {
        y1=Gdx.graphics.getHeight();
    }
    if (y2<0-Gdx.graphics.getHeight()) {
        y2 = Gdx.graphics.getHeight();
    }
}

}
